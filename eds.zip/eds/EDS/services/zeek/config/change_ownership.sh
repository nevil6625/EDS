#/bin/bash
chown -R zeek:zeek /usr/local/zeek/logs/spool/zeek
