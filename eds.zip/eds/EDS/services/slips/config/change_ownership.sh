#/bin/bash
chown -R slips:slips /StratosphereLinuxIPS/output
